﻿

namespace DIP_Before
{
    interface IBase
    {

        void Add();
        void Remove();
        void Delete();


    }


    class MyProject : IBase
    {
        public void Add()
        {

        }
        public void Remove()
        {

        }
        public void Delete()
        {

        }
    }


    class Derivate : IBase
    {
        public void Add()
        {

        }
        public void Remove()
        {

        }
        public void Delete()
        {

        }
    }


    class Respose_Project
    {

        private IBase? Base;

        public void Save()
        {
            Base = null;
        }



    }

}

