﻿

/*
 

Indi biz sabahlari bize Electronic class lazim olsa amma elimizde olmasa biz 
onun yenine elektronicclassindan implement eliyen bir nece classi istifade ede bilerik yalniz 
onun yenini vermiye biler amma yenede istifade etmis olariq
 */
namespace LSP_After
{


    class ELectronic
    {
        public string Data { get; set; }
      
    }


    class Komputer : ELectronic
    {

        public void Aftomatic_Yazma()
        {

        }
    }
    class Telephon:ELectronic
    {
        public void Mesaj_Yazma()
        {

        }
    }

    class Planshet : ELectronic
    {

        public void Yazmaq()
        {

        }
    }




}


