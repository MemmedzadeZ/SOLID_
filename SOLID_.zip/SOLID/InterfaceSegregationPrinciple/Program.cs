﻿

namespace ISP_After
{ 

    interface IServer
    {
        void Serverhtps(string region);
        void ServerList(string region);

    }

    interface IMatherBorn
    {
        void StoreFile(string path);
        void getFile(string path);  
    }


    class Basic_Data : IServer,IMatherBorn
    {
       

        public void StoreFile(string path)
        {
           
        }

        public void getFile(string path)
        {
           
        }

        public void Serverhtps(string region)
        {
        }

        public void ServerList(string region)
        {
            
        }
    }


    class Derived_Data : IServer
    {
        public void Serverhtps(string region)
        {
            
        }

        public void ServerList(string region)
        {
            
        }
    }




}
