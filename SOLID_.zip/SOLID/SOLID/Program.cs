﻿

/*
     
    Bizim bir Insan clasimiz var  bu classin icinde biz bu 3 methodun 3 de cagirsaq
    onda bir isci hem structur qura hem ev tike hemde alqisatqi ede bilecek
    amma biz her bir isciye gore (memar usta reseption )-a gore ferqli ferqli classlar 
    qursaq o zaman biz her bir isci ozune gore isi etmeye baslayacaq yeniki
    before yazdigim sehv mentiqdir 
     
*/


namespace SRP_After
{

    
    class Insan
    {
        public int Id { get; set; } 
        public string? Name { get; set; }
        public string? Surname { get; set; }
        public string? Email { get; set; }

    }


    class Memar
    {
        public void Structur_Qurmaq(Insan insan) { }
    }

    class Usta
    {
        public void Ev_Tikmek(Insan insan) { }
    }
    class Reseption
    {
        public void Ev_Alqisatqisi(Insan insan) { } 
    }

}